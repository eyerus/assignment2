var express = require('express');
var fs = require('fs');
var app = express();

app.use(express.static('public'));



app.get('/greeting', function(req, res){

var name = req.query.name;
//var final = parseInt(num);
var result = "welcome " + name;
 res.send(result); 
//res.send("hey there");

});

app.listen(3000);